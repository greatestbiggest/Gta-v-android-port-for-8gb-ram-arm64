# SN512A GTA V - GLUE5 V8.1 (experimental unknown-WASM build)

The uploaded game.wasm is 63,202,762 bytes / SHA256 dcd3dc966ae8ab78637137580da990f9acec2ecfba6c47d153bdc15e4b60ca02. Official GLUE5 supports only 63,201,802-byte game.wasm / SHA256 11ca8d2c04c5e843d18ff4aea4899d72c86973c6b031df334e67c446b2ae83e0.

This workflow is an *experimental probe*, not a fix or assurance that the unknown game version is compatible. It uses GLUE5's documented GLUE5_ALLOW_UNKNOWN_BUILD=1 flag, while matching only the exact uploaded file digest. It may fail while resolving engine hooks, compiling, running, or rendering; if it fails, use the official matching game.wasm instead. It does NOT trim 960 bytes, patch game.wasm, or pretend the byte differences are unimportant.

How to run:
1. Upload sn512a-v8-1-glue5-768-alternate-wasm.yml to your repo .github/workflows/ via GitHub's Add file > Upload files or web editor.
2. Keep your existing game.wasm in your PRIVATE DRAFT RELEASE. Never publish it or commit it.
3. Actions > SN512A GTA V V8.1 - GLUE5 768MiB Alternate WASM Probe (experimental) > Run workflow.
4. If the build succeeds, APK will be in the same private draft release; preserve the signing keystore.
5. If it fails, send the first RED ERROR from the compile step.

Crucial: A successful compile is not proof the GLUE5 memory hooks match the alternate version. This is only a controlled compatibility probe.
